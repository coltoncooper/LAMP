<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	public $totalgold;

	public function __construct()
	{
		parent::__construct();

		$this->session->set_userdata('ninjalog');

		$this->totalgold = 0;
		// $this->output->enable_profiler();
	}

	public function index()
	{
		$this->load->view('main_view');
	}

	public function process_money()
	{
		$this->totalgold =$this->totalgold +  $this->calculate_win($this->input->post('building'));
		$view_data = array('totalScore'=>$this->totalgold);
		$this->load->view('main_view', $view_data);
	}

	private function calculate_win($building)
	{

		if($this->input->post('building') == "farm"){
			$earned = rand(10,20);
			// array_push($this->session->userdata('ninjalog', "You went to the farm and earned"." ". $earned." gold!".date("m/d/Y h:i:s a", time())));
			
			// array_unshift($_SESSION['color'],'green');
			// array_unshift($_SESSION["activity"], "You went to the farm and earned"." ". $earned." gold!".date("m/d/Y h:i:s a", time()));
		}elseif($this->input->post('building') == "cave"){
			$earned = rand(5,10);
			
			// array_unshift($_SESSION["color"], 'green');
			// array_unshift($_SESSION["activity"], "You went to the cave and earned"." ". $earned." gold!".date("m/d/Y h:i:s a", time()));
		}elseif($this->input->post('building') == "house"){
			$earned = rand(2,5);
			
			// array_unshift($_SESSION["color"], 'green');
			// array_unshift($_SESSION["activity"], "You went to the house and earned"." ". $earned." gold!".date("m/d/Y h:i:s a", time()));
		}elseif($this->input->post('building') == "casino"){
			$earned = rand(-50,50);

			if($earned<0){
				// array_unshift($_SESSION["color"], 'red');
				// array_unshift($_SESSION["activity"], "You went to the casino and lost"." ". $earned." gold!".date("m/d/Y h:i:s a", time()));
			}else{
				// array_unshift($_SESSION["color"], 'green');
				// array_unshift($_SESSION["activity"], "You went to the casino and earned"." ". $earned." gold!".date("m/d/Y h:i:s a", time()));
			}
		}
		return $earned;
	}
}

//end of main controller