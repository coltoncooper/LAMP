<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function new_user()
	{
		echo "New User";
	}
}