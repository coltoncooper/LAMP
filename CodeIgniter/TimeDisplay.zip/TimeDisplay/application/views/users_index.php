<!DOCTYPE html>
<html>
<head>
	<title>All Users</title>
</head>
<body>
	<h1>Users index page coming from the Users controller Index Method
</body>
</html>