<html>
<head>
	<title></title>
</head>
<body>
	<form action="courses/destroy" method="post">
		<input type="text" value='<?php echo $id ?>' hidden >
		<button type="button">NO</button>
		<button type="submit">Yes</button>


	</form>

</body>
</html>