<?php
session_start();
require_once('mysql-connection.php'); 
?>